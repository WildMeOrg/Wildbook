#! /bin/sh
#cd /Users/Jason/Interconnect
#java -cp ./Interconnect.jar org.ecocean.interconnect.Interconnect http://www.whaleshark.org/InterconnectSubmitSpots