#! /bin/sh
#cd /Users/Jason/Interconnect
#java -cp ./Interconnect.jar org.ecocean.interconnect.Interconnect http://<your_wildbook_server_URL>/InterconnectSubmitSpots