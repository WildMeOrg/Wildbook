#! /bin/sh
# cd <your_path_to_the_client_here>
# java -classpath .:jdo-api-3.0.jar -Xms256m -Xmx1024m org.ecocean.grid.WorkApplet3 http://<path_to_your_wildbook_server>