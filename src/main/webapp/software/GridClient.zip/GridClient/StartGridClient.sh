#! /bin/sh
# cd <your_path_to_the_client_here>
# java -classpath .:javax.jdo-3.2.0-m3.jar:commons-math3-3.2.jar:datanucleus-api-jdo-4.2.0-release.jar:datanucleus-core-4.1.7.jar -Xms256m -Xmx4096m org.ecocean.grid.WorkAppletHeadlessEpic http://34.209.17.78
